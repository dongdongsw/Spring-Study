package com.sist.aop;

import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Aspect // 공통기반의 처리가 있는 경우 처리
// footer : Cookie 처리
@Component
public class SiteAOP {

}
