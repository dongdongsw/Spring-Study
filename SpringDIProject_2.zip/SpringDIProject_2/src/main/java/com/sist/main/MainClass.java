package com.sist.main;
/*
 *  DL	DI	AOP	=> MVC
 * 					|
 * 					web개발 (첨부된 라이브러리)
 * 			 |
 * 			공통 모듈
 * 		|
 * 		객체 생성시에 필요한 멤버 변수의 값을 주입 (데이터베이스)
 *   | 
 *   클래스 찾기(getBean(id명))
 *   동작 순서
 *   ------
 *   1. 객체 생성
 *   	------ 라이브러리 => XML, Annotation
 */
public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
